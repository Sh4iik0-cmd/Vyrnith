// Funzione di validazione del modulo
function validateForm() {
    // Recupera i dati dal modulo
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const role = document.getElementById("role").value;
    const message = document.getElementById("message").value;

    // Verifica se i campi obbligatori sono vuoti
    if (name === "" || email === "" || role === "" || message === "") {
        alert("Per favore, completa tutti i campi obbligatori.");
        return false;
    }

    // Verifica se l'email ha un formato corretto
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailPattern.test(email)) {
        alert("Per favore, inserisci un'email valida.");
        return false;
    }

    // Se tutte le verifiche sono passate, invia il modulo
    alert("Candidatura inviata con successo!");
    return true;
}

// Aggiunge l'evento al modulo per la validazione prima dell'invio
document.querySelector("form").addEventListener("submit", function(event) {
    // Previene l'invio del modulo se la validazione fallisce
    if (!validateForm()) {
        event.preventDefault();
    }
});
